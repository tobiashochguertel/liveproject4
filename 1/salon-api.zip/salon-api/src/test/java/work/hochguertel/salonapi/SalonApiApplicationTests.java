package work.hochguertel.salonapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalonApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
